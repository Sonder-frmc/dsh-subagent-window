# 子智能体弹出对话窗口 · `@local/subagent-window`

状态（2026-11-26，v3.10）：**代码已更新到 v3.10（T1 整洁型二轮瘦身：zh/en 合表 + best-effort 统一，行 −7.82%，行为与 UI 零变化，见「v3.10 整洁型瘦身（T1）」）**。插件已安装：profile 以 `source=link:D:\DSHGZQ\plugins\subagent-window` 指向本目录，修改 `lib/client.js` 后刷新页面即可生效（无需重装）。当前 GUI：`http://127.0.0.1:65475`（端口随会话变化）。写作用域仅本目录 `D:\DSHGZQ\plugins\subagent-window\`；未改 profile、未改 `D:\DeepSeek\resources\app.asar`、未写目录外文件。

## 一句话结论

v3 不再有左侧栏「子智能体」行和主区面板；改为：**右侧栏「开始」页新增「子智能体」卡片**（打开一页子智能体列表，可查看/打开对话/打开浮窗）；**两处右键菜单**（会话头部、右侧栏标签右键）提供「打开浮窗/关闭浮窗」；浮窗仍是应用内 `subagentchat` 浮动面板，查看/发消息/接受权限确认/停止全部由内置对话 UI 提供。

## 交付物索引

| 文件 | 内容 |
|---|---|
| `README.md` | 本文件：v3 说明、实现记录、自检、安装与回滚、已知局限 |
| `01-feasibility.md` | 可行性结论、三条实现路径对比、证据（只读）、依赖与风险、备选方案 |
| `02-engineering-prompt.md` | 工程提示词 v2（需求与实现基线） |
| `03-requirement-confirmation.md` | 需求确认包（Q1–Q6 已确认 + Q7 默认 + A1–A11 验收） |
| `05-modification-research.md` | v3 改造定位研究（Start 页/右键菜单证据、文件:行号、风险） |

## 包结构

```
D:\DSHGZQ\plugins\subagent-window\
  package.json           # name @local/subagent-window, exports "."→lib/index.js, "./client"→lib/client.js
  cordis.patch.yml       # - insert: [{id: subagent-window, name: '@local/subagent-window'}]
  icon.svg
  lib\index.js           # Host 侧：export function apply() {}（空）
  lib\client.js          # Client 侧：window.__ModuleLoader__.load({...})，全部逻辑在此（v3）
  locale\zh.json         # 插件 meta 显示信息
  locale\en.json
  README.md
```

## v3 变更记录（相对 v2 实现）

1. **删除左侧栏与主区入口**：移除 `sidebar.panellist` 行注册（原 `lib/client.js:715-727`）与 `main` key=`subagent-window` 面板注册（原 `:728-731`）；删除 `SidebarIcon`、`SubagentPanel` 组件；浮窗 helper（`openFloat`/`closeFloatByContent`/`floatExistingTabContent`/`ensureSurface`/rect 逻辑/`collectDescendants`/`addressOf`）全部保留。
2. **右侧栏「开始」页卡片**：注册新 tab 类型 `@local/subagent-window`（kind `subagent-window`、`priority:"builtin"`、`guide:[{id:"open", order:25, title, description}]`），并把页体注册到 `sidebar.right.pane.tab`（key=类型 id）、标题注册到 `sidebar.right.pane.tab.title`。卡片点击由内置 `openTab(kind,{replaceTab:true})` 打开本页（`05-modification-research.md` §2）。
3. **会话头部右键菜单**：在 `conversation.session.header.actions`（list/session）注册零尺寸锚点 `WindowMenuAnchor`（`lib/client.js:528`）——`inject` 拿到 `sessionId`，`ref.current.closest("header")` 给整个头部挂原生 `contextmenu` 监听；菜单体 `WindowMenuOverlay`（`:595`）注册到 root-scoped `shell.overlay` list，`position:fixed` 按点击坐标渲染，`Escape`/外部 `pointerdown`/滚动/缩放关闭；目标为子智能体会话时两项（打开/关闭浮窗），目标为主会话时列出该会话全部子智能体、逐行提供两项；若取不到 `<header>` 或 `sessionId`，降级为锚点处的可见「⋯」按钮（不静默崩溃）。
4. **右侧栏标签右键菜单**：在 `sidebar.right.tab.menu.item`（list/session，props=`{tab,dismiss}`）注册 `TabMenuItem`（`:734`）——仅当 `tab.kind === "subagentchat"` 且 contentId 为 `dsh-resource://subagentchat/...` 时渲染两个 `role="menuitem"` 按钮（打开浮窗/关闭浮窗），点击先 `dismiss()` 再动作。
5. **浮窗打开/关闭复用**：打开=已有 tab 则 `sidebarRight.float(tab.id, rect)`，没有则 `openResource(contentId,{kind:"subagentchat",preferNewPane:true})` 后 `float`；关闭=`sidebarRight.close(tabId)`。tab 记录 `contentId` 即完整 subagentchat 地址，可在 `screen().surface.layout.tabs` 中精确找回。
6. **locale**：运行期字典改为 `tab.*/guide.*/page.*/menu.*` 键（内联在 `lib/client.js`）；`locale/*.json` 的 meta 描述更新为 v3。面板/菜单状态依赖 `ctx.sessions.list.subscribe`，浮窗状态刷新用 1200ms 轻量轮询（sidebarRight 无公开订阅）。

## v3 关键证据（只读源码）

- Start 页=sidebar-right 内置 guide tab：`dsh-client-ui-sidebar-right/lib/client.js:4785-4786`（"开始"/"更多工具"）、`:4830` GUIDE_ID、`:4732-4739` guide 条目聚合、`:606-653` GuideBody、`:633` 卡片点击 `openTab(kind,{replaceTab:true})`、`:1368-1415` TabSlot body key=类型 id、`:5101-5126` guide/body/title slot 注册。
- 现成 tab 类型范式：`dsh-client-ui-sidebar-browser/lib/client.js:1429-1450`（definition+guide）、`:1599-1606` 注册、`:1614-1629` body、`:1635-1639` title；files `:22-37`、terminal `:438-451`、inspector `:4131-4143`。
- 右侧栏 tab 右键挂载点：`dsh-client-ui-sidebar-right/lib/client.js:1548-1551`（`renderTabMenuItems: (tab,dismiss) => renderSlot("sidebar.right.tab.menu.item", {tab, dismiss})`）。
- 会话头部 DOM/slot：`dsh-client-ui-conversation/lib/client.js:17964-17976`（`<header data-window-drag>` + `renderSlot("conversation.session.header")`）、`:18114` ConversationSessionHeader、`:18152-18202` titleRow（lineage `:18185`、headerActions `:18193`）、`:20022-20059` slot 声明（`conversation.session.header.actions` list/session）。
- `shell.overlay` root list slot：`dsh-client-ui-layout/lib/client.js:623-658`。
- 右栏内嵌会话复用同一 header：`dsh-client-ui-subagent/lib/client.js:786-810`（`renderFactorySlot("conversation.content",{variant:"embedded"})`）、`:833-838`（`sidebar.chat.conversation`）。
- 子智能体地址/tab 契约：`ctx.sessions.subagentAddress(id)`；tab `contentId` = `dsh-resource://subagentchat/session/<child>?parent=<parent>&mode=<mode>`。

## 浮窗可用性（v3.2）

- **右下角缩放热区 28×28**：`[data-dockkit-float]:has([data-sidebar-chat]) > [data-dockkit-float-resize]` 的手柄由 dockkit 默认 20×20 放大到 28×28（`!important`），并提升 `z-index`、显式 `cursor:nwse-resize`、`touch-action:none`，避免「抓不中」。**角标仍只在鼠标悬浮浮窗时淡入**（未常显，用户明确要求不常显，未改 `:after` 的 opacity/visibility）。
  - 选 28 而非 32 的原因：浮窗右下角 32px 区域盖住的是输入框右下角的「发送/停止」按钮（`.GRgSLq_primary` 34×34，距浮窗右边约 16px、距底部约 12px）；32×32 会盖住按钮右下角约 16×20px，28×28 只覆盖约 12×16px（仍比原生 20×20 大 40%），对可点内容的遮挡更小。
- **位置与尺寸钳制**：`clampRect()` 把浮窗 rect 限制在应用窗口内（四周留 12px 边距 `FLOAT_MARGIN`），宽度 ≥240、高度 ≥180 且不超过视口；`openFloat` / `floatExistingTabContent` 的 `float()` 入参与 `lastRect` 都经 `clampRect`，`defaultRect()` 本身也返回钳制后的 rect，修掉「浮窗越出窗口导致内容被裁」。
- **尺寸记忆**：同一页面会话内用 `lastRect` 记住上次浮窗 rect（仅内存，不写 layout 持久化）。
- **明确不支持**：dockkit 无四边/四角缩放、无最大化 API；`sidebarRight.float()` 只在 tab 停靠时一次性设定 rect，浮着的窗不能再改尺寸 —— 因此**四边缩放与最大化不支持**（用户已确认接受）。
- 生效方式：改的是 Client 代码，按 F5 刷新页面即可；无需重装插件。

## v3.3 子智能体行右键

- **行为**：鼠标悬停在「N 个子智能体 ⌄」展开的列表**某一行**上右键 → 出现贴指针的小菜单「打开浮窗 / 关闭浮窗」，作用于该行的子智能体；菜单复用 `.sw_menu`（`position:fixed`，按指针坐标渲染并自动钳到视口），不再盖住列表主体。
- **实现**：在 `apply(ctx)` 的 effect `subagent-window: row context menu` 里注册 document 捕获期 `contextmenu` 监听；命中 `[role="treeitem"]` 后由 `resolveTreeitemSessionId(rowEl)` 反解会话 id，再 `openHeaderMenu({x,y,sessionId})` 复用现有菜单与按钮逻辑（不另写动作）。命中自家 UI（`[data-plugin="subagent-window"]`）或反解失败时静默返回。
- **id 反解**：优先沿 React fiber 向上（≤6 层）找 `fiber.key`，并用 `snapshot.byId` 校验（避免误抓无关 key）；失败时取行内 `[class*="_label"]` 文本（缺失则 `aria-label`）→ `matchSessionIdByLabel`（先精确匹配，再互为前缀匹配，仅唯一命中才接受）；仍失败则不弹菜单、不报错。
- **大菜单避让**：会话头部的 `WindowMenuAnchor` 在目标为 `[role="treeitem"]` 时不再弹大菜单（交给行级菜单）；另外，当内置子智能体列表处于展开状态（头部触发器 `[aria-haspopup="tree"][aria-expanded="true"]`）时也不弹大菜单，避免遮挡；列表关闭后恢复原行为。
- **依赖与失效面**：依赖内置 `dsh-client-ui-subagent` 的行结构（`role="treeitem"`、`aria-label`、外层 React key = childSessionId、下拉 portal 到 `document.body` 且带 `role="tree"`）与头部触发器的 `aria-haspopup/aria-expanded`。DSH 升级若改动这些结构，行级右键会**静默降级**（不弹菜单），其余功能（v3.2 浮窗、头部/标签右键菜单、开始页卡片）不受影响。

## v3.4 浮窗出界修复（Windows 标题栏偏移）

- **根因**：dockkit 浮窗渲染为 `top: max(var(--dsh-dockkit-float-top, 0px), y)`（app.asar @105602426）；桌面壳带原生 Windows 标题栏时 CSS 把 `--dsh-dockkit-float-top` 设为 `--dsh-windows-titlebar-height + 20px`（app.asar @104674364，全屏时 20px）。之前只按 `y + height <= vh` 钳制，忽略了这个下移量，所以底部仍会越界被裁。
- **修复**：新增 `floatTopOffset()`（无 `data-windows-titlebar` → 0；全屏 → 20；否则解析 `--dsh-windows-titlebar-height`（解析失败回退 32）+20；整体异常 → 0）；`clampRect()` 改用「可用高度 = `documentElement.clientHeight` − topOffset」计算 `maxH`/`maxY`（宽度用 `clientWidth`，x 方向不变）；`openFloat`/`floatExistingTabContent` 成功浮出后读取真实浮窗元素的 `--dsh-dockkit-float-top` 存入 `measuredTopOffset`，优先于推导值（兼容上游改实现）。
- **拖动越界兜底**：`window` 捕获期 `pointerup`（effect `subagent-window: reclaim out-of-bounds float`）找到当前浮着的 `subagentchat` tab：rect 与 `clampRect(rect)` 差 >2px 时，`closeFloatByContent` 后按 contentId 反解出的地址 `openFloat` 重开（800ms 防抖，避免循环）。窗口内正常拖动/缩放差 ≤2px 不触发；停靠在主区/右侧栏的对话不在 `floats` 里，不会误触发。
- **行右键 label 兜底硬化**（v3.3 加固）：label 兜底路径现在只在「行文本/aria-label 含 token 特征（如 `23.4M tok`）」且「内置目录已展开（`aria-expanded="true"`）或行能回溯到内置 catalog 的 `role="tree"` 下拉」时才生效；fiber key 命中路径不变。避免主区文件树里同名节点被误判（M5/M7）。
- 生效：F5 刷新即可；拖动出界后松手会「闪一下」再收回窗口内，属预期。

## v3.5 行级菜单被内置列表遮挡（portal 修复）

- **现象**：右键子智能体目录列表中的某一行，列表正常打开着，但本插件的小菜单看不见 / 被列表盖住。
- **根因**：内置目录下拉是 react-dom portal 挂到 `document.body`（`ui-subagent` 的 `createPortal(...)`，CSS `.rezYhW_menu{position:fixed;z-index:100}`）；本插件菜单原来渲染在 `shell.overlay` slot 内，处在布局层 stacking context 里，子元素 z-index 再高也压不过 body 上的 portal。
- **修复 A（层级）**：`WindowMenuOverlay` 改为 `ReactDOM.createPortal(menuNode, document.body)`（新增 `const ReactDOM = require("react-dom")`；web boot 的 `staticModules` 已暴露 `react-dom`，非新依赖）。`.sw_menu` 自身 `position:fixed;z-index:2147483000` 不变，portal 外层不再套 fixed 容器（避免又形成 stacking context）；`createPortal` 不可用时退回内联渲染（不崩）。
- **修复 B（不遮列表）**：行级菜单改为「贴列表外侧」：`rowMenuAnchor()` 取 `rowEl.closest('[role="tree"]')` 的 rect，优先放列表右侧（`treeRect.right + 8`，需约 300px 宽放得下），否则放左侧（`treeRect.left - 8 - 300`）；x/y 统一钳制在视口内（菜单按 300×260 估算，8px 边距）。头部右键大菜单保持原「指针位置」定位不变。
- 关闭行为不变：外部 `pointerdown` / `Esc` / 滚动 / resize 关闭；菜单内按钮点击后关闭。
- 生效：F5 刷新即可。

## v3.6 拖动越界收回未触发（延迟判定修复）

- **现象**：把子智能体浮窗拖到应用窗口之外松手，窗口停在外面不收回（v3.4 的 reclaim 没触发）；窗口内正常拖动/缩放无感。
- **根因**：dockkit 的拖动只在它自己的 `window` **冒泡期** `pointerup` 里提交新 rect（`t.moveFloat(h, M.x, M.y)` / `t.resizeFloat(h, M)`）；本插件 v3.4 把 reclaim 挂在 `window` **捕获期**，先于 dockkit 执行，`currentFloatRect()` 读到的是拖动前的旧 rect，判定「未越界」→ 永远不收回。
- **修复（v3.6）**：捕获期监听保留，但只做轻量筛选（`[data-dockkit-float]` 或其 grip/resize 子元素才安排），随后用 `setTimeout(0)` + `requestAnimationFrame` 把「越界判定」推迟到 dockkit 提交 rect 之后；判定阈值仍为 >2px，边界仍用 `clampRect`（含 v3.4 的 topOffset）。收回时先把 `clamped` 写回 `lastRect` 再 `closeFloatByContent` + `openFloat`，使重开位置 = 离松手位置最近的合法 rect；保留 800ms 防抖与 `reclaiming` 防重入。
- **行为**：拖动过程中仍可能看到窗口出界；松手后自动收回（会闪一下）。窗口内正常拖动/缩放不闪、不重开；缩放导致越界同样收回。
- 生效：F5 刷新即可。

## v3.7 拖动时误收回 / 收回后右栏自动展开（两个根因修复）

- **现象 1**：浮窗拖到窗口下方边缘附近时，每次拖动都会触发「收回/闪一下」。
  - 根因：`clampRect` 的 y 上限原为 `usableH - height - margin`（`usableH = vh - topOffset`，`topOffset≈52`），比真实可用区间多减了一个标题栏偏移；而 dockkit 渲染是 `top = max(topOffset, y)`，只要 `y ≥ topOffset` 真实底部就是 `y + height`，允许上限应为 `vh - height - margin`。于是窗口被拖进底部约 52px 带内就会被判越界 → 每次拖动都收回。
  - 修法：`maxY = Math.max(FLOAT_MARGIN, vh - height - FLOAT_MARGIN)`；`maxH` 仍按 `usableH` 约束（保证 y 最小时顶部在标题栏下、底部不裁）。
- **现象 2**：收回重开时右侧边栏被自动展开。
  - 根因：收回走 `closeFloatByContent → openFloat`；关掉最后一个 subagentchat tab 后右栏 surface 可能卸载，`openFloat → ensureSurface()` 会调 `layout.openRightbar(false,false)` 把右栏打开。
  - 修法：收回前记录 `wasExpanded = rightbarExpanded()`（优先 `sidebarRight.isExpanded()`，回退 `layout.expanded`；两者都拿不到时返回 `null` 表示未知）；`openFloat(address, { restoreCollapsed: wasExpanded === false })`——**仅当能确认原本是收起状态**时，`openFloat` 完成后才 `api.layout.closeRightbar()`（try/catch 忽略异常）；状态未知时不主动收起，避免误关用户已展开的右栏。正常「打开浮窗」路径不传该参数，行为不变。
- 其余不变：捕获期筛选 + `setTimeout(0)`/`rAF` 延迟判定、`lastRect = clamped` 后再关+开、800ms 防抖与 `reclaiming` 防重入。
- 生效：F5 刷新即可。

## v3.8 打开/收回浮窗不再自动展开右侧栏

- **现象**：右栏原本收起时点「打开浮窗」，浮窗出现但右侧栏也被展开；把浮窗拖出界触发收回（关+开）后右栏同样被展开。
- **根因**：`ensureSurface()` 只在 `screenLayout()` 为空时调 `openRightbar`，但随后 `sidebarRight.openResource(...)` 为浮窗新建 tab 必然要求右栏展开（右栏是 tab 的宿主），而 v3.7 只在 reclaim 路径按需 `closeRightbar`，正常「打开浮窗」路径从不收回。于是首次打开后右栏一直展开；reclaim 里 `rightbarExpanded()` 读到的已是「展开」→ 不再恢复。
- **修复（v3.8）**：`openFloat` 入口先记录 `wasExpanded = rightbarExpanded()`；`ensureSurface()` 返回 `{ opened }` 表示本次是否由我们临时展开；浮窗确认浮出后由 `shouldRestoreRightbar(wasExpanded, surface, options)` 决定是否调用 `restoreCollapsedRightbar(tab, contentId, address)`：
  - 用户原本收起（`wasExpanded === false`）→ 恢复收起；
  - 状态未知且是我们自己展开的（`wasExpanded === null && surface.opened`）→ 恢复收起；
  - 原本展开（`true`）→ 一律不动。
- **连带卸载的兜底**：`closeRightbar()` 后等约 400ms 确认浮窗仍存活（`floatedSubagentTab()` 且 `currentFloatRect()`）；若宿主把浮窗随右栏一起卸载，则 `openRightbar` 重新挂载并 `float` 重新浮出一次；仍失败则保持展开（退回旧行为）并置 `restoreCollapseFailed`，之后不再反复尝试，避免抖动。任何路径都不向调用方抛错。
- **行为**：打开/收回浮窗不再改变右栏展开状态（右栏收起时打开浮窗仍收起）；若宿主收起右栏会连带卸载浮窗，则退化为「右栏保持展开」，浮窗不丢。
- 生效：F5 刷新即可。

## v3.9 瘦身（零功能/零 UI 变化）

- 范围：仅 `lib/client.js`（+ 本 README 说明）。删除真正死代码、合并重复的 JSX/注册样板与重复 CSS 声明块；不改任何行为、文案、DOM 结构、类名、`data-*`、`z-index`、时序与阈值。
- 主要删除/合并：
  - `findTab` / `paneOfTab` / `floatedSubagentTab` / `currentMainSessionId` / `modeOf` 统一走 `rowsOf(...).find(...)`（等价遍历）；
  - 两处右键菜单 + 面板行共 7 个按钮抽为内部组件 `ActionButton`（逐字保留 `type/role/className/disabled/onClick/文本`）；
  - `apply()` 的 5 处 `ctx.slots.inject → ctx.slots.register` 抽为 `registerSlot(options, component)`；
  - `SubagentPage` 两个返回分支共享 `renderHeader(count)`（空态计数仍为 `"0"`）；
  - 删除只赋值不读取的死字段 `api.slots`、`api.sidebarRightTabs`；
  - 3 组完全相同的 CSS 声明合并为组合选择器（每个选择器的声明集合逐项不变，见 `_tmp_v39/css-diff.json`）；
  - 删除装饰性 `// ----` 分隔注释行（保留全部根因/时序/回退 why 注释）。
- 度量：1576 行 / 60382B → 1482 行 / 57392B（行 −5.96%、字节 −4.95%）。未达 10% 的原因：CSS 36 行、zh/en 字典 46 行以及「时序/阈值/文案/DOM 逐字不变」的硬约束已冻结大部分体积，剩余可合并的 JSX 结构有限，继续压缩会破坏可读性或触碰冻结语义。
- 验证方式：`node --check` ×2、`check-static.js`（104 断言）、`test-clamp` 7/7、`test-match` 8/8、`test-rowmenu` 7/7、`test-rightbar` 13/13、`final-verify` 全 PASS；另做 CSS 选择器/声明等价 diff（`_tmp_v39/css-diff.json`）与 DOM/属性计数等价（`_tmp_v39/attribute-diff.json`），明细见 `_tmp_v39/removal-report.md`。
- 回滚：把 `_tmp_v39/client.before-v3.9.js` 复制回 `lib/client.js`（README 用 `_tmp_v39/README.before-v3.9.md`）后 F5。
- 已知局限不变（仍见 v3.2–v3.8 各条）；M1–M19 验收点不变。

## v3.10 整洁型瘦身（T1，零功能/零 UI 变化）

- 范围：仅 `lib/client.js`（+ 本 README 说明）；只做「合表 / 统一 best-effort / 等价格式化」，不改行为、文案、DOM、类名、`data-*`、`z-index`、时序与阈值。
- 主要改动：
  - zh/en 字典合并为 `MESSAGES` 表（每键一行 `[zh, en]`，46 个键文案逐字不变），`zh`/`en` 由它派生，`locale.register` 的 NS 与对象 shape 不变；
  - 23 处「同步 try/catch 后回退」统一为 `attempt(work, fallback)` helper：静默吞掉 / `setStatus(errorMessage)` 上报 / `return false|null` 回退三类语义仍由各调用点决定，未互换；async 与 Promise 链内的 try/catch 保留原样；
  - 等价格式化：`openHeaderMenu` 状态对象单行、`inject` 数组单行、`TabMenuItem`/`restoreCollapsedRightbar` 等 best-effort 分支合并（仅结构变化）。
- 主动放弃（评估后判定不能逐字等价或负收益）：
  - `run/busy` 抽 hook：两处 `run` 的 `setState` 调用次数与顺序、`bump()` 位置不同，无法逐字等价；
  - 重复 `className` 提常量：净增常量行，行数指标负收益；
  - `hasTokenSignal` / `inCatalogTree` 等窄函数保持原样（包一层 `attempt` 反而更长）。
- 度量：1482 行 / 57392B → 1366 行 / 56604B（行 −7.82%、字节 −1.37%）；重复 3 行块 121 → 93（−23.14%）；`try {` 30 → 7；`attempt(` 25 处（含 1 处 helper 定义）。
- 验证方式：`node --check` ×2、`check-static.js`（104 断言未改）、`test-clamp` 7/7、`test-match` 8/8、`test-rowmenu` 7/7、`test-rightbar` 13/13、`final-verify` 全 PASS；CSS 选择器/声明等价（`_tmp_v310/css-diff.json`：40→40、missing/changed/added 均空）；DOM/属性计数等价（`_tmp_v310/attribute-diff.json`：mismatches=[]）。
- 回滚：把 `_tmp_v310/client.before-v3.10.js` 复制回 `lib/client.js`（README 用 `_tmp_v310/README.before-v3.10.md`）后 F5。
- 已知局限不变（仍见 v3.2–v3.9 各条）；M1–M19 验收点不变。

## 自检命令与输出（最近一次）

```powershell
cd D:\DSHGZQ\plugins\subagent-window
node --check lib\client.js        # exit=0
node --check lib\index.js         # exit=0
node -e "const fs=require('fs'); for (const f of ['package.json','locale/zh.json','locale/en.json']) JSON.parse(fs.readFileSync(f,'utf8')); console.log('JSON ok')"
```

- 禁项 grep（`lib/client.js`、`lib/index.js`）：无 `require("@deepseek-ai/...`、无 `document.body.appendChild`、无 `window.open`、无 `process.env`、无硬编码 `#hex` —— 无匹配。
- 删除确认 grep：`sidebar.panellist` / `name: "main"` / `PANEL_ID` —— 无匹配。
- `lib/client.js`：1366 行，约 55KB（v3.10）。

## 安装 / 生效 / 回滚

- 本包已由 profile 以 `source=link` 指向本目录；**改文件后按 F5 刷新 Web 页面**即可加载新客户端代码（Host 侧 `lib/index.js` 为空、无 Host 逻辑）。
- 若需重装：`plugin_manager action=install_bundle target=D:\DSHGZQ\plugins\subagent-window`（绝对目录路径；等价 `file:D:\DSHGZQ\plugins\subagent-window`）。
- 验证：`list_plugins` 的 `subagent-window` 行 `enabled=true`、`fiberPhase=active`；刷新后左栏不再有「子智能体」行，右栏「开始」页出现「子智能体」卡片。
- 回滚：`plugin_manager action=remove_bundle target=@local/subagent-window`（或移除 profile 引用后重启）。

## 已知局限 / 未验证项

- 未做 live GUI 验证（本任务只做静态自检）：`shell.overlay` 菜单层级、header 上 `contextmenu` 与 `data-window-drag` 拖拽的交互、dockkit tab 菜单 extras 插入顺序，均需刷新后按下方清单实测。
- 依赖 `dsh-client-ui-subagent` 提供的 `subagentchat` tab 与地址协议（Lead 已核实该插件 enabled=true、fiberPhase=active）；若不可用，打开浮窗会失败。
- 头部右键依赖 `<header>` 元素与 `closest("header")`；上游若改 DOM 结构，锚点仍在但监听会降级为可见「⋯」按钮（组件不崩）。
- 点击「开始」页卡片默认 `replaceTab: true`，会替换右栏当前页签；如希望不替换需改自定义 guide.entry 卡片。
- 菜单只对 `origin === "subagent"` 且能沿 `parentId` 链回到目标会话的行生效；跨 workspace 不处理。
- 浮窗状态「已弹窗」最多 1.2s 后同步（外部手动关窗时）。
- v3.2：右下角 28×28 缩放手柄的命中区与输入框「发送/停止」按钮（34×34，距浮窗右边约 16px、距底约 12px）的右下角有小范围重叠；手柄区域内的点击会被 resize 捕获，若实测影响按钮点击可再缩回 20×20 或改用自定义角标手柄（M6 待实测）。
- v3.2：**四边缩放与最大化不支持** —— dockkit 无四边/四角缩放与 maximize API，`sidebarRight.float()` 只在 tab 停靠时一次性设定 rect（用户已确认接受）。
- v3.3：行级右键依赖内置 ui-subagent 的 DOM/React fiber 结构（`[role="treeitem"]`、`aria-label`、外层 fiber key=childSessionId）与 `aria-haspopup="tree"` 触发器；升级 DSH 后可能失效——失效仅表现为「行级右键无菜单」（静默降级），不影响其它功能。
- v3.4：浮窗顶部偏移依赖 dockkit 的 `--dsh-dockkit-float-top` / `--dsh-windows-titlebar-height` CSS 变量与 `html[data-windows-titlebar]` 属性；若上游改掉这些实现，`floatTopOffset()` 会回退为 0，底部仍可能被裁，需要再校准（已做 `measuredTopOffset` 优先，但仍依赖该变量存在）。
- v3.4：拖动/缩放越界只在 `pointerup` 时收回（收回顾名思义会闪一下），拖出期间不做实时约束；若松手发生在浏览器窗口外（没有 pointerup），要等下一次鼠标释放/点击才收回。
- v3.4：label 兜底仅在内置目录展开且有 tok 特征时生效（fiber key 路径不受影响）；若内置行不再显示 token 文本，兜底会静默失效。
- v3.5：菜单 portal 依赖 web boot 的 `staticModules` 暴露 `react-dom`（当前已确认存在，见 `_tmp_scan/web/index-BXV-oxvX.js` 的 `OZ()`）；若某版本移除，会退回内联渲染并可能再被 body 级 portal 遮挡，但不崩。
- v3.5：行级菜单定位按「列表约 400px 宽、菜单约 300×260」估算；列表几乎占满视口宽度时左右都放不下，只能钳制到 8px 边距（此时靠 portal 层级仍可见，但可能部分盖住列表，属极端窗口宽度下的取舍）。
- v3.6：收回依赖 `setTimeout(0)` + `requestAnimationFrame` 推迟到 dockkit 提交 rect 之后；若上游改成在 pointermove 期间就提交、或不再在 pointerup 提交 rect，判定时机需重新校准。
- v3.6：拖出界松手后会「闪一下」重开（关+开），浮窗里未发送的草稿/滚动位置会丢失（沿用 v3.4 的已知代价，用户已接受）。
- v3.7：收回后恢复右栏收起状态依赖 `layout.closeRightbar()` 存在且不连带卸载浮窗，且只在 `rightbarExpanded()` 能确认为收起时执行（`isExpanded()`/`layout.expanded` 都不可用时返回未知、不主动收起）；若某些版本收起右栏会连浮窗一起关掉，会退回「右栏被打开」的旧行为（F5 验收时重点看）。
- v3.7：y 越界判定改为以 viewport 底部为准（不再额外减标题栏偏移）；若 dockkit 未来把浮窗渲染改成 `top = topOffset + y`（而非 `max`），底部约束会偏差一个 topOffset，需要再校准。
- v3.8：恢复右栏收起依赖 `layout.closeRightbar()` 不连带卸载浮窗；若会连带卸载，则走 `openRightbar` + 重新 `float` 的兜底（可能看到右栏短暂闪一下、浮窗重开一次），兜底成功后右栏仍保持展开；兜底也失败则置 `restoreCollapseFailed` 并不再尝试（下次打开浮窗保持旧行为）。
- v3.8：`shouldRestoreRightbar` 的「未知状态且本次展开」分支依赖 `ensureSurface` 的返回值；若某些版本 `isExpanded()`/`layout.expanded` 都不可用且右栏并非本次展开，则不主动收起（避免误关用户已展开的右栏）。
- v3.10：zh/en 文案统一维护在 `lib/client.js` 的 `MESSAGES` 表（新增/修改文案键需同步该表，`locale.register` 的 shape 不变）；`attempt(work, fallback)` 只负责「同步异常回退」，catch 的吞掉/上报/回退语义仍由各调用点显式决定，不是通用容错层。

## 待用户 GUI 验证点（F5 刷新后）

1. 左侧栏没有「子智能体」行；主区没有「子智能体」面板（此前打开过的旧 tab 可手动关掉）。
2. 右侧栏「开始」页出现「子智能体」卡片（排在「新建终端」和「浏览器」之间），点击打开子智能体列表页。
3. 主区会话头部（含「N 个子智能体 ⌄」那行）任意位置右键 → 菜单；主会话时逐行列子智能体，子智能体会话时只针对本会话。
4. 右侧栏子智能体对话头部右键 → 同样菜单（打开浮窗/关闭浮窗）。
5. 右侧栏标签条上 `subagentchat` 标签右键 → dockkit 菜单中出现「打开浮窗」「关闭浮窗」。
6. 打开浮窗后：可查看/发消息/接受权限/停止；关闭浮窗不结束子智能体。
7. 「打开浮窗」重复点击/多窗口并存/关闭后状态刷新是否正常。
8. 子智能体列表（头部「N 个子智能体 ⌄」下拉的 `role="tree"` 列表）中悬停某一行右键 → 贴指针小菜单「打开浮窗/关闭浮窗」，作用于该行；列表打开时右键头部其它空白不弹大菜单，列表关闭后大菜单恢复（v3.3）。
9. 打开子智能体浮窗：整窗都在应用窗口内，Windows 标题栏存在时底部按钮/输入框也不再被裁（v3.4）。
10. 把浮窗拖到窗口右/下边缘之外松手 → 自动收回窗口内（会闪一下）；窗口内正常拖动/缩放不闪、不重复打开（v3.4）。
11. 右键主区文件树中与子智能体同名的行 → 不弹本插件菜单（M7，v3.4 硬化）；右键内置子智能体目录列表中的行仍弹行级小菜单。
12. 右键子智能体目录列表中的行 → 小菜单出现在列表右侧（右侧放不下则左侧）空白处、完整可见、不被列表或其它层压住；点「打开浮窗」正常（v3.5）。
13. 把子智能体浮窗拖到应用窗口之外（右/下）松手 → 自动收回窗口内，位置贴近松手处（不跳回上次位置）；窗口内正常拖动/缩放不闪不重开；缩放到越界后松手同样收回（v3.6）。
14. 把浮窗拖到窗口下方边缘附近（不拖出界）反复拖动/缩放 → 不应闪、不应被收回；真正拖出界松手 → 收回窗口内且贴近松手处，同时右侧边栏保持原来的展开/收起状态（原本收起时不被自动打开）（v3.7）。
15. 右侧栏**收起**时点「打开浮窗」→ 浮窗出现，右侧栏保持收起、不被自动展开（v3.8，M1）。
16. 右侧栏**展开**时点「打开浮窗」→ 右栏仍展开，不被莫名收起（v3.8，M2）。
17. 拖出界松手触发收回（关+开）后 → 右栏维持原来的展开/收起状态（v3.8，M3）。
18. 收回后浮窗不能丢：若右栏状态正确但浮窗消失，说明连带卸载兜底没生效，报 prompt-helper（v3.8，M4）。
19. 回归：v3.5 行右键菜单、v3.7 贴底不误收、缩放/出界修复（v3.8，M5）。

## 验收

安装后按 `03-requirement-confirmation.md` 的 A1–A11 验收；`02-engineering-prompt.md` 末尾列出可执行步骤与预期结果；v3 变更另见 `05-modification-research.md`。
